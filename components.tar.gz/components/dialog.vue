<style>
    .sk-com-clear{
        clear: both;
    }
    .sk-dialog-position{
        width: 100%;
        height: 100%;
        position: fixed;
        top:0;
        left: 0;
        z-index: 1000;
    }
    .sk-dialog-bg{
        position: fixed;
        top:0;
        left:0;
        width: 100%;
        height: 100%;
        background:rgba(0, 0, 0, 0.7);
        overflow: scroll;
        z-index: 1;
        display: block;
    }
    .sk-dialog{
        z-index: 9999;
        position: relative;
        margin: 50% auto;
        width: 75%;
        border-radius: 0.5rem;
        background-color: #fff;
        box-shadow: 0.1rem 0.1rem 0.7rem #545151;
        font-family: "Microsoft YaHei";
    }
    .sk-dialog-top{
        padding: 1.5rem 0 0.5rem 0;
        border-top-right-radius: 0.7rem;
        border-top-left-radius:0.7rem;
        font-size: 1.3rem;
        color: #4A4949;
        text-align: center;
    }
    .sk-dialog-tit{
        display: inline-block;
    }
    .sk-dialog-close{
        position: absolute;
        top: -1.37rem;
        right: -1.37rem;
        display: inline-block;
        width: 2rem;
        height: 2rem;
        background: url("/images/roundclose.png") no-repeat center;
        background-size: 1.8rem auto;
    }
    .sk-dialog-cont{
        padding: 1.2rem 1rem;
        text-align: center!important;
        color: #3E3A39;
    }
    .sk-dialog-txt{
        font-size: 1.2rem;
        line-height: 1.5rem;
        text-align: center;
    }
    .sk-dialog-btn{
        width: 100%;
        line-height: 3.7rem;
        color: #3E3A39;
        font-size: 1.3rem;
        border-top: 1px solid #E5E8E8;
        text-align: center;
    }
    .sk-dialog-cancel{
        text-align: center;
        display: inline-block;
        border-bottom-right-radius:0.7rem;
        width: 49%;
        box-shadow: -1px 0 0 0 #E5E8E8;

    }
    .sk-dialog-ture{
        text-align: center;
        display: inline-block;
        border-bottom-left-radius:0.7rem;
        width: 49%;
    }
</style>


<template>
    <div class="sk-dialog-position">
        <div>
            <div class="sk-dialog">

                <div class="sk-dialog-top">
                    <div class="sk-dialog-tit">
                        <strong>{this.title}</strong>
                    </div>
                    {if this.hasClose}
                    <div class="sk-dialog-close" @click="hide"></div>
                    {/if}
                </div>

                <div class="sk-dialog-cont">
                    <div class="sk-dialog-txt" >
                        {if this.url==""}
                        <p>{this.text}</p>
                        {else}
                        <iframe src="{this.url}"></iframe>
                        {/if}
                    </div>
                </div>
                <div class="sk-dialog-btn">
                    {if this.hasOk}
                    <div class="sk-dialog-ture" @click="pickOk">{this.okText}</div>
                    {/if}
                    {if this.hasCancel}
                    <div class="sk-dialog-cancel"  @click="pickCancel">{this.cancelText}</div>
                    {/if}
                    {foreach from=this.buttons}
                    <div class="sk-dialog-cancel"  @click="pickButton:{i}">{item}</div>
                    {/foreach}
                </div>
                <div class="sk-com-clear"></div>
            </div>

        </div>
        <div class="sk-dialog-bg"></div>
    </div>
</template>


<script>
    var mod = exp.model = {
        title: "提示",
        text: "内容",
        url: "",
        okText: "确定",
        cancelText: "取消",
        hasClose: false,
        hasOk: true,
        hasCancel : false,
        onOk: null,
        onCancel: null,
        onButton: null
    };

    var exp = {};

    exp.mediaStyle = true;
    exp.timer = null;

    exp.methods = {
        //点击确定按钮
        pickOk: function () {
        exp.timer && window.clearTimeout(exp.timer);
        exp.hide();
        mod.onOk && mod.onOk();
    };

    //点击取消按钮
    pickCancel: function () {
        exp.hide();
        mod.onCancel && mod.onCancel();
    },

    //点击其他按钮
    pickButton: function (index) {
        exp.hide();
        mod.onButton && mod.onButton(index);
    }
    };

    //警告框
    exp.alert = function(ops){
        if(typeof ops=="string") {
            ops = {text: ops};
            for(var i=1; i<arguments.length; i++){
                var v = arguments[i];
                typeof v == "number" && (ops.timeout = v);
                typeof v == "function" && (ops.onOk = v);
            }
        }
        ops.hasCancel = false;
        exp.showDialog(ops);
    };

    //确认框
    exp.confirm = function(ops){
        if(typeof ops=="string"){
            ops = {
                text: arguments[0],
                onOk: arguments[1],
                onCancel: arguments[2]
            };
        }
        ops.hasCancel = true;
        exp.showDialog(ops);
    };

    //显示对话框
    exp.showDialog = function(ops){
        obj.merge(mod, ops);
        mod.onOk = ops.onOk || null;
        mod.onCancel = ops.onCancel || null;
        exp.show();
        exp.render();

        if(ops.timeout>0){
            exp.timer = window.setTimeout(exp.pickOk, ops.timeout);
        }
    };

    exports default exp;
</script>