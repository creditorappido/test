define(function(require, exports) {
    "use strict";

    //使用插件
    exports.use = function (plugin, box) {
        this.parseStyle(plugin.style);
        this.parseTemplate(plugin.getTemplate);
        plugin.render = function(){

            box.innerHTML = this.html;
        };

        var o = {};
        Arrays.like(arguments).forEach(function(m){
            o[m] = plugin[m];
        });
        return o;
    };

    //解析样式
    exports.parseStyle = function(style){

    };

    //解析样式
    exports.parseTemplate = function(fun){
        this.code = [];
        plugin.getTemplate.call(plugin.model, this.start, this.set, this.end, this.text);
        this.code = this.code.join("\n");
        alert(this.code);
    };

    /*
    exports.add = function(tag){
        tag = tag.split(".");
        var html = '<' + tag[0];
        if(tag[1]){
            html += tag[1]
        this.code += '>';
        this.code += 'a.push('+html+');'
    };


    exports.set = function(tag){

    };

    exports.src = function(tag){
        var html = '<' + tag[0];
        if(tag[1]) {
            html += tag[1];
        }
        this.code += '>';
        this.code += 'a.push('+html+');'
    };

    exports.for = function(){

    };

    exports.end = function(){

    };*/

});