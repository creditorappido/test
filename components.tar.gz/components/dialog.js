define(function(require, exports, module) {
    "use strict";
    var skPlugin = require("./skPlugin");
    var exp = {};

    //样式
    exp.style = {
        "sk-com-clear": {
            clear: "both"
        },
        "sk-dialog-position": {
            width: "100%",
            height: "100%",
            position: "fixed",
            top: 0,
            left: 0,
            zIndex: 1000
        },
        "sk-dialog-bg": {
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0, 0, 0, 0.7)",
            overflow: "scroll",
            zIndex: 1,
            display: "block"
        },
        "sk-dialog": {
            zIndex: 9999,
            position: "relative",
            margin: "50% auto",
            width: "75%",
            borderRadius: "0.5rem",
            backgroundColor: "#fff",
            boxShadow: "0.1rem 0.1rem 0.7rem #545151",
            fontFamily: "Microsoft YaHei"
        },
        "sk-dialog-top": {
            padding: "1.5rem 0 0.5rem 0",
            borderTopRightRadius: "0.7rem",
            borderTopLeftRadius: "0.7rem",
            fontSize: "1.3rem",
            color: "#4A4949",
            textAlign: "center"
        },
        "sk-dialog-tit": {
            display: "inline-block"
        },
        "sk-dialog-close": {
            position: "absolute",
            top: "-1.37rem",
            right: "-1.37rem",
            display: "inline-block",
            width: "2rem",
            height: "2rem",
            background: "url('roundclose.png') no-repeat center",
            backgroundSize: "1.8rem auto"
        },
        "sk-dialog-cont": {
            padding: "1.2rem 1rem",
            textAlign: "center!important",
            color: "#3E3A39"
        },
        "sk-dialog-txt": {
            fontSize: "1.2rem",
            lineHeight: "1.5rem",
            textAlign: "center"
        },
        "sk-dialog-btn": {
            width: "100%",
            lineHeight: "3.7rem",
            color: "#3E3A39",
            fontSize: "1.3rem",
            borderTop: "1px solid #E5E8E8",
            textAlign: "center"
        },
        "sk-dialog-cancel": {
            textAlign: "center",
            display: "inline-block",
            borderBottomRightRadius: "0.7rem",
            width: "49%",
            boxShadow: "-1px 0 0 0 #E5E8E8"
        },
        "sk-dialog-ture": {
            textAlign: "center",
            display: "inline-block",
            borderBottomLeftRadius: "0.7rem",
            width: "49%"
        }
    };

    //模板
    exp.template = function (data) {
        return this
        .add("div.sk-dialog-position")
            .add("div.sk-dialog")
                .add("div.sk-dialog-top")
                    .add("div.sk-dialog-tit").end("div")
                    .add("strong").text(data.title).end("strong")
                .end("div")
                .set("if").condition(data.hasClose)
                    .add("div.sk-dialog-close").on("click", "hide").end("div")
                .end("if")
                .add("div.sk-dialog-cont")
                    .add("div.sk-dialog-txt")
                        .set("if").condition(data.url=="")
                            .add("p").text(data.text).end("p")
                        .set("else")
                            .add("iframe").src(data.url).end("iframe")
                        .end("if")
                    .end("div")
                .end("div")
                .add("div.sk-dialog-btn")
                    .set("if").condition(data.hasOk)
                        .add("div.sk-dialog-ture")
                            .on("click", "pickOk")
                            .text(data.okText)
                        .end("div")
                    .end("if")
                    .set("if").condition(data.hasCancel)
                        .add("div.sk-dialog-cancel")
                            .on("click", "pickCancel")
                            .text(data.cancelText)
                        .end("div")
                    .end("if")
                    .set("foreach").src(data.buttons)
                        .add("div.sk-dialog-cancel")
                            .on("click", "pickButton", index)
                            .text(item)
                        .end("div")
                        .add("p").text(index).end("p")
                    .end("foreach")
                .end("div")
                .add("div.sk-com-clear").end("div")
            .end("div")
            .add("div.sk-dialog-bg").end("div")
        .end("div");
    };

    var mod = exp.model = {
        title: "提示",
        text: "内容",
        url: "",
        okText: "确定",
        cancelText: "取消",
        hasClose: false,
        hasOk: true,
        hasCancel: false,
        onOk: null,
        onCancel: null,
        onButton: null
    };

    exp.mediaStyle = true;
    exp.timer = null;

    //点击确定按钮
    exp.pickOk = function () {
        exp.timer && window.clearTimeout(exp.timer);
        exp.hide();
        mod.onOk && mod.onOk();
    };

    //点击取消按钮
    exp.pickCancel = function () {
        exp.hide();
        mod.onCancel && mod.onCancel();
    };

    //点击其他按钮
    exp.pickButton = function (index) {
        exp.hide();
        mod.onButton && mod.onButton(index);
    };

    //警告框
    exp.alert = function (ops) {
        if (typeof ops == "string") {
            ops = {text: ops};
            for (var i = 1; i < arguments.length; i++) {
                var v = arguments[i];
                typeof v == "number" && (ops.timeout = v);
                typeof v == "function" && (ops.onOk = v);
            }
        }
        ops.hasCancel = false;
        exp.showDialog(ops);
    };

    //确认框
    exp.confirm = function (ops) {
        if (typeof ops == "string") {
            ops = {
                text: arguments[0],
                onOk: arguments[1],
                onCancel: arguments[2]
            };
        }
        ops.hasCancel = true;
        exp.showDialog(ops);
    };

    //显示对话框
    exp.showDialog = function (ops) {
        obj.merge(mod, ops);
        mod.onOk = ops.onOk || null;
        mod.onCancel = ops.onCancel || null;
        exp.show();
        exp.render();

        if (ops.timeout > 0) {
            exp.timer = window.setTimeout(exp.pickOk, ops.timeout);
        }
    };

    module.exports = skPlugin.use(exp, "alert", "confirm");

});